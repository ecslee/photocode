# eseitz - Emily Seitz
# 4/23/12
# 6.815 pset10

* 8 hours
* none that I know of
* I added the 1 pixel border around the sub-apertures.
* none, just Piazza browsing
* it was pretty straight forward, just took time to debug
* it is pretty amazing that the code consolidates all those 289 photos into one focused image!
