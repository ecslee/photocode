# eseitz - Emily Seitz
# 3/12/12
# 6.815 A5

* this assignment took ~9hrs.  I had one really silly bug that I chased for a while… adding an index to my results instead of list[index] haha :)
* I implemented everything, but my design HDR is super dark.  I can't figure out where the tone mapping went wrong--it looks fine on the other images!
* none
* only with Piazza classmates
* I, like many other people, was confused about the chaining factors in assembly the HDR.
* the resulting HDR's were cool and the tone mapping results on the nature photos.