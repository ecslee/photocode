# eseitz - Emily Seitz
# 5/7/12
# 6.815 pset12

- 3 hours
- none
- none
- none
- straight forward, it wasn't confusing
- cool results!
- For pset 13, I want to implement "Color 2 Gray."
