# eseitz - Emily Seitz
# 2/21/12
# 6.815 A2

import numpy
import imageIO
import math
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)


################################
# Functions from lecture slides:
################################

def imIter(im):
    for y in xrange(im.shape[0]):
        for x in xrange(im.shape[1]):
            yield y, x

def getBlackPadded(im, y, x):
    if (x<0) or (x>=im.shape[1]) or (y<0) or (y>= im.shape[0]):
        return numpy.array([0, 0, 0])
    else:
        return im[y, x]

def height(im):
    return im.shape[0]

def width(im):
    return im.shape[1]

def clipX(im, x):
    return min(width(im)-1, max(x, 0))

def clipY(im, y):
    return min(height(im)-1, max(y, 0))

def getSafePix(im, y, x):
    return im[clipY(im, y), clipX(im, x)]

def scaleBAD(im, k):
    out = imageIO.constantIm(im.shape[0]*k, im.shape[1]*k, 0)
    for y, x in imIter(im):
        out[k*y, k*x]= im[y, x]
    return out


################################
# Functions by me:
################################

# 3.1 - basic scaling with nearest neighbor
def scaleNN(im, k):
    scaled = imageIO.constantIm(height(im)*k, width(im)*k, 0.0)
    for y, x in imIter(scaled):
        scaled[y, x] = im[y/k, x/k]
    return scaled


# 3.2 - scaling with bilinear interpretation
def scaleLin(im, k, edge):
    scaled = imageIO.constantIm(height(im)*k, width(im)*k, 0.0)
    for y, x in imIter(scaled):
        scaled[y, x] = interpolateLin(im, y/k, x/k) if edge else interpolateLinBlack(im, y/k, x/k)
    return scaled

def is_int(n):
    return numpy.floor(n) == numpy.ceil(n)

def interpolateLin(im, y, x):
    # assuming edge padding
    y = clipY(im, y)
    x = clipX(im, x)

    if is_int(y):
        if is_int(x):
            return im[y][x]
        else:
            x_only = (x-numpy.floor(x))*im[y][numpy.ceil(x)] + (numpy.ceil(x)-x)*im[y][numpy.floor(x)]
            return x_only
    else:
        if is_int(x):
            y_only = (y-numpy.floor(y))*im[numpy.ceil(y)][x] + (numpy.ceil(y)-y)*im[numpy.floor(y)][x]
            return y_only
        else:
            # linear on x for top
            x_top = (x-numpy.floor(x))*im[numpy.floor(y)][numpy.ceil(x)] + (numpy.ceil(x)-x)*im[numpy.floor(y)][numpy.floor(x)]
            # linear on x for bottom
            x_bot = (x-numpy.floor(x))*im[numpy.ceil(y)][numpy.ceil(x)] + (numpy.ceil(x)-x)*im[numpy.ceil(y)][numpy.floor(x)]
            # linear on y for both
            y_both = abs(y-numpy.ceil(y))*x_top + abs(y-numpy.floor(y))*x_bot
            return y_both

def interpolateLinBlack(im, y, x):
    # using black padding
    if is_int(y):
        if is_int(x):
            return getBlackPadded(im, y, x)
        else:
            x_only = (x-numpy.floor(x))*getBlackPadded(im, y, numpy.ceil(x)) + (numpy.ceil(x)-x)*getBlackPadded(im, y, numpy.floor(x))
            return x_only
    else:
        if is_int(x):
            y_only = (y-numpy.floor(y))*getBlackPadded(im, numpy.ceil(y), x) + (numpy.ceil(y)-y)*getBlackPadded(im, numpy.floor(y), x)
            return y_only
        else:
            # linear on x for top
            x_top = (x-numpy.floor(x))*getBlackPadded(im, numpy.floor(y), numpy.ceil(x)) + (numpy.ceil(x)-x)*getBlackPadded(im, numpy.floor(y), numpy.floor(x))
            # linear on x for bottom
            x_bot = (x-numpy.floor(x))*getBlackPadded(im, numpy.ceil(y), numpy.ceil(x)) + (numpy.ceil(x)-x)*getBlackPadded(im, numpy.ceil(y), numpy.floor(x))
            # linear on y for both
            y_both = abs(y-numpy.ceil(y))*x_top + abs(y-numpy.floor(y))*x_bot
            return y_both


# 4.2 - warping according to one pair of segments
# 2D points = numpy.array(x, y)

# calculates magnitude of a vector
def mag(vector):
    return math.sqrt(vector[0]**2 + vector[1]**2)

# calcuates the dot product between two vectors
def dotProd(vector1, vector2):
    return vector1[0]*vector2[0] + vector1[1]*vector2[1]

# calculates perpindicular vector to a segment
def perp(vector):
    return numpy.array([vector[1], -vector[0]], dtype=numpy.float64)

class segment:
    def __init__(self, x1, y1, x2, y2):
        self.p1 = numpy.array([x1, y1], dtype=numpy.float64)
        self.p2 = numpy.array([x2, y2], dtype=numpy.float64)
        self.vector = numpy.array([x2-x1, y2-y1], dtype=numpy.float64)

    def __add__(self, other):
        return segment(self.p1[0]+other.p1[0], self.p1[1]+other.p1[1], self.p2[0]+other.p2[0], self.p2[1]+other.p2[1])
    
    def __sub__(self, other):
        return segment(self.p1[0]-other.p1[0], self.p1[1]-other.p1[1], self.p2[0]-other.p2[0], self.p2[1]-other.p2[1])

    def __mul__(self, k):
        return segment(self.p1[0]*k, self.p1[1]*k, self.p2[0]*k, self.p2[1]*k)

    def transform(self, point, source):
        segX = segment(self.p1[0], self.p1[1], point[0], point[1])
        u = dotProd(segX.vector, self.vector) / dotProd(self.vector, self.vector)
        v = dotProd(segX.vector, perp(self.vector)) / math.sqrt(dotProd(self.vector, self.vector))
        # x_prime = X in source image
        # p_prime = P in source = source.p1
        # q_prime = Q in source = source.p2
        x_prime = source.p1 + u*source.vector + (v*perp(source.vector))/math.sqrt(dotProd(source.vector, source.vector))
        return x_prime

def warpBy1(im, segmentBefore, segmentAfter):
    warped = imageIO.constantIm(height(im), width(im), 0.0)
    for y, x in imIter(warped):
        x_prime = segmentAfter.transform([x, y], segmentBefore)
        warped[y][x] = im[clipX(im, x_prime[1])][clipY(im, x_prime[0])]
    return warped

# 4.3 - warping according to multiple pairs of segments
def shortestDist(point, line):
    perp = perp(line)
    m = perp[1]/perp[0]
    b = point[1] - m*point[0]

# following pseudocode from Beier pg. 37
def warp(im, listSegmentsBefore, listSegmentsAfter, a=10, b=1, p=1):
    warped = imageIO.constantIm(height(im), width(im), 0.0)
    for y, x in imIter(warped):
        DSUM = (0, 0)
        weightsum = 0.0
        for s in range(len(listSegmentsAfter)):
            x_orig = numpy.array([x, y], dtype=numpy.float64)
            x_prime = listSegmentsAfter[s].transform([x, y], listSegmentsBefore[s])
            segX = segment(listSegmentsAfter[s].p1[0], listSegmentsAfter[s].p1[1], x, y)
            disp = x_prime - x_orig

            u = dotProd(segX.vector, listSegmentsAfter[s].vector) / dotProd(listSegmentsAfter[s].vector, listSegmentsAfter[s].vector)
            v = dotProd(segX.vector, perp(listSegmentsAfter[s].vector)) / math.sqrt(dotProd(listSegmentsAfter[s].vector, listSegmentsAfter[s].vector))
            if (0 <= u < 1):
                dist = abs(v)
            elif (u < 0):
                dist = math.sqrt((x - listSegmentsAfter[s].p1[0])**2 + (y - listSegmentsAfter[s].p1[1])**2)
            elif (u >= 1):
                dist = math.sqrt((x - listSegmentsAfter[s].p2[0])**2 + (y - listSegmentsAfter[s].p2[1])**2)

            weight = ((mag(listSegmentsBefore[s].vector)**p) / (a + float(dist)))**b
            DSUM += disp * weight
            weightsum += weight
        x_prime = x_orig + DSUM / weightsum
        warped[y][x] = im[clipY(im, x_prime[1])][clipX(im, x_prime[0])]
    return warped

# 4.4 - morphing
def morph(im1, im2, listSegmentsBefore, listSegmentsAfter, N=1, a=10, b=1, p=1):
    currentSegments = safe_copy(listSegmentsBefore)
    nextSegments = safe_copy(listSegmentsBefore)

    imageIO.imwrite(im1, 'morph000.png')
    im2 = warp(im2, listSegmentsAfter, listSegmentsBefore)
    i = 0
    
    for n in range(1, N+1):
        i+=1
        currentSegments = safe_copy(nextSegments)
        step = listSegmentsBefore*(1-(n/float(N))) + listSegmentsAfter*(n/float(N))
        a = warp(im1, listSegmentsBefore, step)
        b = warp(im2, listSegmentsBefore, step)
        imageIO.imwrite(a*(1-(n/float(N))) + b*(n/float(N)), 'morph'+str('%03d' %i)+'.png')
    pass

# numpy.copy() was not working correctly for my segments,
# so I wrote a safer 
def safe_copy(a):
    b = []
    for x in a:
        b.append(segment(x.p1[0], x.p1[1], x.p2[0], x.p2[1]))
    return numpy.array(b)
