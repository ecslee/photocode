eseitz - Emily Seitz
2/21/12
6.815 - Assignment 2

* 8 hours
* I don't notice any issues in the running of the code.  Sometimes the colors in my images come out lighter than expected, but I'm not sure if that's a bug or a feature.
* no extra credit
* I only collaborated with the comments I saw on Piazza.
* The assignment wasn't very confusing.
* It was interesting that the whole process really just followed those algorithms in the paper.  It was really cool when things worked :)
