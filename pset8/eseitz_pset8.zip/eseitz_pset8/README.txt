# eseitz - Emily Seitz
# 4/9/12
# 6.815 pset8

- 3 hours + a few hours because I fixed pset7
- sometimes, my autostitch returns a memory error.  I assume that sometimes it is not doing RANSAC well and getting a homography that results in a bounding box with ridiculously huge dimensions.
- none
- just Piazza
- it was pretty straight forward
- the images look nice!
