Emily Seitz
02/13/2012
6.815 A1

* 4 hours
* My code succeeds in all the tests.
* I looked at the Piazza discussion boards, but I did not collaborate with anyone else.
* It took me a while to figure out what the contrast function was asking for.  The rest of the pset was pretty straightforward, after reading the comments and questions on Piazza.
* I love processing my own pictures in iPhoto, Photoshop, etc. so it was soo cool to process that little zebra picture using only python!!  It's really interesting that the processing is almost entirely matrix operations--I love the beauty of math :)