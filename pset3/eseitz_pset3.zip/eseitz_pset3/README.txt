# eseitz - Emily Seitz
# 2/27/12
# 6.815 A3

- 8hrs.
- My solutions don't all match exactly with the results that Prof. Durand posted, but they are pretty close.
- None.
- I compared results with Kenny Lam, but other than that I only "collaborated" by checking Piazza posts.
- I got a little stuck on the Gaussian filtering... then realized that I was making it way more complicated than it really was.
- The results with the Sobel kernel are amazing -- edge detection in my pset!
- Timed results:
    Separable Gauss = 6.921sec
    2D Gauss = 38.274sec
