# eseitz - Emily Seitz
# 3/19/12
# 6.815 A6

* 5hrs
* I don't see any issues :)
* I implemented the 6.835 assignment "stitchN," and I was able to test it for 3 of the Guedelon images.  I tried with both refIndex=0 and refIndex=1.  I also ran it on all 4 Guedelon images, with refIndex=1.
* just classmates on Piazza
* The part that took me the longest to figure out was what to put in the B vector used in calculating homographies.
* Last year, I took 2 photos of a sunrise that (sadly) I saw over campus.  I wanted to stitch them together as a panorama, and so I searched the internet for free software.  The result I got was okay, but then I got the exact same result with my own code!  So great :D
* I've include the required images and the pano I made from my own sunrise photos.
