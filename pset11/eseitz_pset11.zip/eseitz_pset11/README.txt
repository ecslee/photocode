# eseitz - Emily Seitz
# 5/2/12
# 6.815 pset11

- 4 hours
- none
- none
- none
- this was a super straight forward pset to implement
- I was able to "fix" a photo in which my friend blinked!
- I did two composites of my own:
    1) a sign for an orchard combined with an apple from that orchard
    2) I replaced the eyes of my friend who blinked in a photo with here eyes from another photo :D
