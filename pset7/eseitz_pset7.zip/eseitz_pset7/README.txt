# eseitz - Emily Seitz
# 4/2/12
# 6.815 pset7

- 10 hours
- I did not finish debugging :(  I think there is a problem in my Harris Corner detection which propagated into my other functions as well.  I had to submit in the middle of debugging my RANSAC algorithm, so it also is not complete.  I have included a couple of the results of my pair matching, but they are not very correct looking.
- no extra credit.
- none
- Implementing the structure tensor confused me.  The rest seemed pretty straight-forward, I just didn't finish.
- I was excited to get the auto stitching… but didn't get there.
