# eseitz - Emily Seitz
# 4/2/12
# 6.815 pset 7

import imageIO
from imageIO import *
import numpy
from numpy import *
import scipy.ndimage
import scipy.signal
import a1
from a1 import *
import a6
from a6 import *
import a7help
from a7help import *
import random as rnd
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

# 2.1 - Structure tensor
def computeTensor(im, sigmaG=0.5, factorSigma=4):
    tensor = constantIm(height(im), width(im), 0.0)
    lumi = scipy.ndimage.filters.gaussian_filter(lumiChromi(im)[0][:,:,0], 1.0)**0.5
    Sobel = array([[-1,0,1], [-2,0,2], [-1,0,1]])
    Lx = scipy.signal.convolve(lumi, Sobel, mode="same")
    Ly = scipy.signal.convolve(lumi, transpose(Sobel), mode="same")

    tensor[:,:,0] = scipy.ndimage.filters.gaussian_filter(Lx*Lx, sigmaG*factorSigma)
    tensor[:,:,1] = scipy.ndimage.filters.gaussian_filter(Lx*Ly, sigmaG*factorSigma)
    tensor[:,:,2] = scipy.ndimage.filters.gaussian_filter(Ly*Ly, sigmaG*factorSigma)
    #imwriteSeq(tensor, "tensor-")
    return tensor


# 2.2 - Harris corners
def HarrisCorners(im, k=0.15, sigmaG=0.5, factor=4, maxDiam=7, boundarySize=5):
    tensor = computeTensor(im)
    M = array([0,0,0])
    for n in range(3):
        M[n] = sum(tensor[:,:,n])
    M = matrix([[M[0], M[1]], [M[1], M[2]]])
    
    # corner response
    corners = constantIm(height(im), width(im), 0.0)
    for y, x in imIter(corners):
        mat = matrix([[tensor[y, x][0], tensor[y, x][1]], [tensor[y, x][1], tensor[y, x][2]]])
        corners[y, x] = linalg.det(mat) - k*trace(mat)**2

    # non-maximum suppression
    corners2 = scipy.ndimage.filters.maximum_filter(corners, maxDiam)

    # removing boundary corners
    for y in range(boundarySize):
        corners2[y, :] = 0.0
        corners2[height(corners)-1-y, :] = 0.0
    for x in range(boundarySize):
        corners2[:, x] = 0.0
        corners2[:, width(corners)-1-x] = 0.0

    # putting it all together
    cornersList = []
    for y, x in imIter(corners2):
        if sum(corners2[y, x]) > 1e-2:
            if corners2[y,x,0]==corners[y,x,0] and corners2[y,x,1]==corners[y,x,1] and corners2[y,x,2]==corners[y,x,2]:
                cornersList.append(array([y, x]))
    #visualizeCorners(im, cornersList)
    return cornersList


# 3.1 - Descriptors
def computeFeatures(im, cornerL, sigmaBlurDescriptor=0.5, radiusDescriptor=4):
    blur = scipy.ndimage.filters.gaussian_filter(lumiChromi(im)[0][:,:,0], sigmaBlurDescriptor)
    featuresList = []
    for P in cornerL:
        featuresList.append(descriptor(blur, P, radiusDescriptor))
    #visualizeFeatures(featuresList, radiusDescriptor, im)
    return featuresList

def descriptor(blurredIm, P, rD):
    patch = []
    patch = blurredIm[P[0]-rD:P[0]+rD+1, P[1]-rD:P[1]+rD+1]
    patch -= mean(patch)
    patch *= std(patch)
    return (P, patch)


# 3.2 - Best match and 2nd best match test
def findCorrespondences(listFeatures1, listFeatures2, threshold=1.7):
    correspondences = []
    for f1 in listFeatures1:
        dist = []
        for f2 in listFeatures2:
            dist.append(sum(f1[1]-f2[1])**2)
        best = (argmin(dist), listFeatures2[argmin(dist)][0])
        dist.remove(min(dist))
        secondBest = (argmin(dist), listFeatures2[argmin(dist)][0])
        if abs(secondBest[0]/best[0]) >= threshold:
            correspondences.append((f1[0], best[1]))
    print len(correspondences)
    return correspondences


# 4 - RANSAC
def RANSAC(listOfCorrespondences, Niter=1000, epsilon=4):
    # bestSoFar = [# inliers, pairs, wellDef, homography]
    bestSoFar = [0, 0, 0, 0]
    for n in range(Niter):
        wellDef = []

        # get 4 random pairs
        pairs = []
        for i in range(4):
            pairs.append(listOfCorrespondences[rnd.randint(0, len(listOfCorrespondences)-1)])
        
        # compute homography
        H = computehomography(pairs)

        # test homography
        for p in pairs:
            mag = array([p[1][0], p[1][1], 1]) - dot(H, array([p[0][0], p[0][1], 1]))
            if sqrt(dot(mag, mag)) < epsilon:
                wellDef.append(True)
            else:
                wellDef.append(False)
        print wellDef

        # is it better?
        if wellDef.count(True) > bestSoFar[0]:
            bestSoFar = [wellDef.count(True), pairs, wellDef, H]

    return bestSoFar

        
        



def test():
    a = imread('pano/stata-1.png')
    b = imread('pano/stata-2.png')
    aC = HarrisCorners(a)
    bC = HarrisCorners(b)
    aF = computeFeatures(a, aC)
    bF = computeFeatures(b, bC)
    co = findCorrespondences(aF, bF)
    visualizePairs(a, b, co)
    ransac = RANSAC(co, 10, 4)
    visualizePairsWithInliers(a, b, ransac[1], ransac[2])
    return
    
        

