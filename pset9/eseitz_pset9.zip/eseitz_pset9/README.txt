# eseitz - Emily Seitz
# 4/12/12
# 6.815 pset9

- 4 hours
- nope
- I did the 6.865 assignment #2.5 to calibrate my own lens.  I have included the source photos and the calibrated results.  You can see that the aberrations are fixed at the edges of the pictures, such as around the lights in the calibration image.
- none
- figuring out how to fill in the coord 3D array
- it worked :)
- Scale factors for '24.png':
        kr = 1.0001875
        kb = 1.0005625
- My lens:
	Olympus Zuiko Digital 14-42mm f3.5-5.6
	calibrated at f = 14mm focal length
	Scale factors:
		kr = 1.000375
		kb = 1.0001875
